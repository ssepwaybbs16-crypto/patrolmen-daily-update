
from flask import Flask, render_template, request, redirect, url_for, session, flash, send_file, abort
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3, os, io, datetime, json
from functools import wraps
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, Border, Side
from openpyxl.utils import get_column_letter

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, "patrolmen.db")
app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "CHANGE_THIS_SECRET_KEY_IN_PRODUCTION")

SEED = [
("1","BBSN-MCS\n(DN & MID)","421/41","425/21","P/BBS/BBSN/P-1-32","860369070024375","ASHOK KUMAR BEHERA","7337213616","ANIRUDH MANGARAJ","9861357466"),
("1A","BBSN-MCS\n(UP)","421/41","429/21A (UP Line)","P/BBS/PTAB/P-2-418","860369070074776","PRAMOD KUMAR","8328888679","DEEPAK MUDULI","9853401799"),
("2","MCS-BBSN\n(DN & MID)","429/21","425/21","P/BBS/MCS/P-3-33","860369070058555","ANUPAM NANDI","7670868960","MD SAKHEEL","8013355138"),
("3","MCS-BBS\n(UP & DN)","429/21","433/11","P/BBS/BNBH/P-4-37","860369070024177","NABIN BEHERA","9237104747","CHITTARANJAN ROUT","9437837541"),
("4","BBS-BNBH\n(UP & DN)","436/15","433/11","P/BBS/BBS/P-5-38","860369070024144","SIMANCHAL CHARCHI","9237104763","BIJAY KUMAR PRADHAN","7381769402"),
("5","BBS-LGTR\n(UP & DN)","436/15A","440/0","P/BBS/LGTR/P-6 -679","860369070156177","GOPABANDHU DAS","9237104770","CHAGALA BARIK","7008948643"),
("6","LGTR-RTN\n(UP & DN)","443/25A-27A\n(LC-192)","440/0","P/BBS/LGTR/P-7-419","860369070074164","BARUN KARMAKAR","8918118501","NIHAR DEO","6371663749"),
("7","RTN-LGTR\n(UP & DN)","443/23A-25A\n(LC-192)","447/0","P/BBS/RTN-54/P-8-438","860369070086515","ALAVILLI ANANTH KUMAR","8917639370","BISWAJIT MOHANTY","8917335565"),
("8","RTN-KUR\n(UP & DN)","447/0","450/7A-9A","P/BBS/RTN-54A/P-9-40","860369070023948","PRABHAT KUMAR MAHARANA","9237104809","SANTOSH NAYAK","9681718015"),
]

def db():
    con=sqlite3.connect(DB)
    con.row_factory=sqlite3.Row
    return con

def init_db():
    con=db()
    con.executescript("""
    CREATE TABLE IF NOT EXISTS gangs(
      id INTEGER PRIMARY KEY AUTOINCREMENT, gang_no TEXT UNIQUE NOT NULL,
      between_section TEXT NOT NULL, from_location TEXT NOT NULL, to_location TEXT NOT NULL,
      gps_device_sl TEXT NOT NULL, gps_imei TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS patrolmen(
      id INTEGER PRIMARY KEY AUTOINCREMENT, gang_id INTEGER NOT NULL, slot INTEGER NOT NULL,
      name TEXT NOT NULL, mobile TEXT NOT NULL, updated_at TEXT,
      UNIQUE(gang_id,slot), FOREIGN KEY(gang_id) REFERENCES gangs(id)
    );
    CREATE TABLE IF NOT EXISTS users(
      id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL, role TEXT NOT NULL, gang_id INTEGER,
      display_name TEXT, FOREIGN KEY(gang_id) REFERENCES gangs(id)
    );
    """)
    if con.execute("SELECT COUNT(*) FROM gangs").fetchone()[0]==0:
        for i,s in enumerate(SEED,1):
            cur=con.execute("""INSERT INTO gangs(gang_no,between_section,from_location,to_location,gps_device_sl,gps_imei)
                         VALUES(?,?,?,?,?,?)""",s[:6])
            gid=cur.lastrowid
            con.execute("INSERT INTO patrolmen(gang_id,slot,name,mobile,updated_at) VALUES(?,?,?,?,?)",
                        (gid,1,s[6],s[7],datetime.datetime.now().isoformat(timespec="minutes")))
            con.execute("INSERT INTO patrolmen(gang_id,slot,name,mobile,updated_at) VALUES(?,?,?,?,?)",
                        (gid,2,s[8],s[9],datetime.datetime.now().isoformat(timespec="minutes")))
            # two unique mate accounts per gang
            for mate in (1,2):
                username=f"G{str(i).zfill(2)}M{mate}"
                password=f"Patrol@{i:02d}M{mate}"
                con.execute("INSERT INTO users(username,password_hash,role,gang_id,display_name) VALUES(?,?,?,?,?)",
                            (username,generate_password_hash(password),"mate",gid,f"Gang {s[0]} Mate {mate}"))
        con.execute("INSERT INTO users(username,password_hash,role,display_name) VALUES(?,?,?,?)",
                    ("ADMIN",generate_password_hash("Admin@2026"),"admin","Section Admin"))
    con.commit(); con.close()

def login_required(f):
    @wraps(f)
    def wrap(*a,**kw):
        if "user_id" not in session: return redirect(url_for("login"))
        return f(*a,**kw)
    return wrap

def admin_required(f):
    @wraps(f)
    def wrap(*a,**kw):
        if session.get("role")!="admin": abort(403)
        return f(*a,**kw)
    return wrap

@app.route("/login",methods=["GET","POST"])
def login():
    if request.method=="POST":
        u=request.form.get("username","").strip().upper()
        p=request.form.get("password","")
        con=db(); user=con.execute("SELECT * FROM users WHERE username=?",(u,)).fetchone(); con.close()
        if user and check_password_hash(user["password_hash"],p):
            session.clear(); session["user_id"]=user["id"]; session["role"]=user["role"]; session["gang_id"]=user["gang_id"]; session["display_name"]=user["display_name"]
            return redirect(url_for("dashboard"))
        flash("Invalid ID or password.")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear(); return redirect(url_for("login"))

@app.route("/")
@login_required
def dashboard():
    con=db()
    if session["role"]=="admin":
        gangs=con.execute("SELECT * FROM gangs ORDER BY id").fetchall()
        data=[]
        for g in gangs:
            p=con.execute("SELECT * FROM patrolmen WHERE gang_id=? ORDER BY slot",(g["id"],)).fetchall()
            data.append((g,p))
    else:
        g=con.execute("SELECT * FROM gangs WHERE id=?",(session["gang_id"],)).fetchone()
        p=con.execute("SELECT * FROM patrolmen WHERE gang_id=? ORDER BY slot",(g["id"],)).fetchall()
        data=[(g,p)]
    con.close()
    return render_template("dashboard.html", data=data, role=session["role"], name=session["display_name"])

@app.route("/gang/<int:gid>/update",methods=["POST"])
@login_required
def update_gang(gid):
    if session["role"]!="admin" and session["gang_id"]!=gid: abort(403)
    con=db()
    for slot in (1,2):
        name=request.form.get(f"name{slot}","").strip()
        mobile=request.form.get(f"mobile{slot}","").strip()
        if name and mobile:
            con.execute("UPDATE patrolmen SET name=?,mobile=?,updated_at=? WHERE gang_id=? AND slot=?",
                        (name,mobile,datetime.datetime.now().isoformat(timespec="minutes"),gid,slot))
    con.commit(); con.close()
    flash("Patrolmen details updated successfully.")
    return redirect(url_for("dashboard"))

@app.route("/admin/gang/<int:gid>",methods=["POST"])
@admin_required
def admin_gang(gid):
    con=db()
    fields=("gang_no","between_section","from_location","to_location","gps_device_sl","gps_imei")
    vals=[request.form.get(x,"").strip() for x in fields]
    con.execute("""UPDATE gangs SET gang_no=?,between_section=?,from_location=?,to_location=?,gps_device_sl=?,gps_imei=? WHERE id=?""",(*vals,gid))
    con.commit(); con.close()
    flash("Gang master details updated.")
    return redirect(url_for("dashboard"))

@app.route("/report.xlsx")
@login_required
@admin_required
def report():
    date=request.args.get("date") or datetime.date.today().strftime("%d-%m-%Y")
    start=request.args.get("start","22.00")
    enddate=request.args.get("enddate") or date
    end=request.args.get("end","06.00")
    con=db()
    gangs=con.execute("SELECT * FROM gangs ORDER BY id").fetchall()
    wb=Workbook(); ws=wb.active; ws.title="PATROLLING"
    ws.merge_cells("B2:J2")
    ws["B2"]=f"MONSOON PATROLING IN SSE/PW/BBS SECTION ON DATE-{date} ({start} Hrs) TO {enddate} ({end}Hrs)"
    ws["B2"].font=Font(bold=True,size=14); ws["B2"].alignment=Alignment(horizontal="center")
    headers=["SL. No","Batch No.","Between Section","Location","","GPS DEVICE SL NO","GPS DEVICE IMEI NO","Name of Patrolmen","Mobile No"]
    for c,v in enumerate(headers,2):
        ws.cell(3,c,v).font=Font(bold=True); ws.cell(3,c).alignment=Alignment(horizontal="center",vertical="center",wrap_text=True)
    ws["E4"]="From"; ws["F4"]="To"
    r=5
    for idx,g in enumerate(gangs,1):
        p=con.execute("SELECT * FROM patrolmen WHERE gang_id=? ORDER BY slot",(g["id"],)).fetchall()
        ws.cell(r,2,idx); ws.cell(r,3,g["gang_no"]); ws.cell(r,4,g["between_section"]); ws.cell(r,5,g["from_location"]); ws.cell(r,6,g["to_location"])
        ws.cell(r,7,g["gps_device_sl"]); ws.cell(r,8,g["gps_imei"]); ws.cell(r,9,p[0]["name"]); ws.cell(r,10,p[0]["mobile"])
        for c in range(2,11): ws.cell(r,c).alignment=Alignment(vertical="center",wrap_text=True)
        for pp in p[1:]:
            r+=1; ws.cell(r,9,pp["name"]); ws.cell(r,10,pp["mobile"])
        r+=1
    thin=Side(style="thin",color="000000")
    for row in ws.iter_rows(min_row=3,max_row=r-1,min_col=2,max_col=10):
        for cell in row: cell.border=Border(left=thin,right=thin,top=thin,bottom=thin)
    widths={2:8,3:12,4:25,5:18,6:18,7:24,8:20,9:28,10:16}
    for c,w in widths.items(): ws.column_dimensions[get_column_letter(c)].width=w
    ws.row_dimensions[2].height=28
    out=io.BytesIO(); wb.save(out); out.seek(0); con.close()
    return send_file(out,as_attachment=True,download_name=f"Patrolmen_in_SSE.PW.BBS_{date}.xlsx",
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

@app.route("/change-password",methods=["GET","POST"])
@login_required
def change_password():
    if request.method=="POST":
        old=request.form.get("old",""); new=request.form.get("new","")
        con=db(); user=con.execute("SELECT * FROM users WHERE id=?",(session["user_id"],)).fetchone()
        if check_password_hash(user["password_hash"],old) and len(new)>=8:
            con.execute("UPDATE users SET password_hash=? WHERE id=?",(generate_password_hash(new),session["user_id"])); con.commit(); con.close()
            flash("Password changed."); return redirect(url_for("dashboard"))
        con.close(); flash("Old password incorrect or new password is too short.")
    return render_template("password.html")

if __name__=="__main__":
    init_db()
    app.run(host="0.0.0.0",port=int(os.environ.get("PORT",5000)),debug=False)
