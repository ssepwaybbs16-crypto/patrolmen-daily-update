# Patrolmen Daily Update App

This app is based on the uploaded Excel format:
"Patrolmen in SSE.PW.BBS on Dt. 18-11-2026.xlsx"

## Features
- 9 gangs seeded from the spreadsheet.
- Two unique mate accounts per gang (18 mate accounts total).
- A mate can only view/update his own gang.
- Mates can update the two patrolmen names and mobile numbers every day.
- Section Admin can view all 9 gangs and edit master fields.
- Admin can download an Excel report matching the source structure, with a dynamic date/time title.
- Passwords are hashed in SQLite and users can change their password.

## Demo accounts
Admin:
  ID: ADMIN
  Password: Admin@2026

Gang mate accounts:
  Gang 1: G01M1 / Patrol@01M1, G01M2 / Patrol@01M2
  Gang 1A: G02M1 / Patrol@02M1, G02M2 / Patrol@02M2
  Gang 2: G03M1 / Patrol@03M1, G03M2 / Patrol@03M2
  Gang 3: G04M1 / Patrol@04M1, G04M2 / Patrol@04M2
  Gang 4: G05M1 / Patrol@05M1, G05M2 / Patrol@05M2
  Gang 5: G06M1 / Patrol@06M1, G06M2 / Patrol@06M2
  Gang 6: G07M1 / Patrol@07M1, G07M2 / Patrol@07M2
  Gang 7: G08M1 / Patrol@08M1, G08M2 / Patrol@08M2
  Gang 8: G09M1 / Patrol@09M1, G09M2 / Patrol@09M2

Change all demo passwords before real deployment.

## Run
1. Install Python 3.10+.
2. Run: `pip install -r requirements.txt`
3. Run: `python app.py`
4. Open: http://127.0.0.1:5000

For actual use by 18 mates on different phones, deploy the Flask app on a secure server/VPS or a managed platform and set SECRET_KEY to a strong random value. Use HTTPS.
